npm install mocha chai --save-dev

npm install mocha --save-dev
npm install chai --save-dev