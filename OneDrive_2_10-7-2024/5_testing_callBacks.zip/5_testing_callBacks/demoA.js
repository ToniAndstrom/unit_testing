'use strict';

// const search=require('./carStorageNoFileop');
const search = require('./carStorageFileNotWorking');

console.log(search());
console.log('##### ONE #####');
console.log(search('model','Nova'));
console.log('##### TWO #####');
console.log(search('licence','ABC-1'));
console.log('##### THREE #####');
console.log(search('model','Bored T-model'));
console.log('##### FOUR #####');